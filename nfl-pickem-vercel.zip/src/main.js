import './style.css';

const games = [
  { home: "Chiefs", away: "Lions" },
  { home: "Eagles", away: "Patriots" },
  { home: "Cowboys", away: "Giants" }
];

document.querySelector('#app').innerHTML = `
  <h1>NFL Pick'em</h1>
  <div>
    ${games.map(game => `
      <label>${game.away} @ ${game.home}:
        <select>
          <option value="${game.away}">${game.away}</option>
          <option value="${game.home}">${game.home}</option>
        </select>
      </label>
      <br/>
    `).join('')}
  </div>
`;
